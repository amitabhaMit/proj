<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function getsupportschool($id = 0)
    {
        $id = $this->input->post('id');
        echo $this->common_model->data_select_record('support_school_master', ['id' => $id])->school_id;
    }

    public function getregularschool($id = 0)
    {
        $id = $this->input->post('id');
        echo $this->common_model->data_select_record('regular_school_master', ['id' => $id])->school_id;
    }
}

/* End of file MY_Controller.php */
