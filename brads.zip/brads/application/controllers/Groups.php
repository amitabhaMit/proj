<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
        
class Groups extends MY_Controller {

    protected $title = 'User Groups';
	protected $trigger = 'groups/';
	protected $table = 'user_group';
        
    public function __construct()
	{
		parent::__construct();
		is_logged_in();
    }
    
    public function index()
    {
        $data = array();
		$data['title'] 	    = $this->title;
		$data['trigger']    = $this->trigger;
        $data['table']	    = $this->table;
        
        $data['results'] = $this->common_model->data_select($data['table'], false, false, 'group_name');
        
        $this->load->view('groups/groups', $data);
    }

    public function edit($id = false)
    {
        $data = array();
		$data['title'] 		= $this->title;
		$data['trigger']	= $this->trigger;
        $data['table']		= $this->table;
        
        if($this->input->post('submit-btn')){
            $id = $this->input->post('id');
            if($id){
                $data_array = array(
                    'group_name'   => ucwords($this->input->post('group_name')),
                    'modified_by'  => $this->session->email,
                    'updated_at'   => date("Y-m-d H:i:s",time())
                );
                $update = $this->common_model->data_update($data['table'], $data_array, ['id' => $id]);
                if ($update) {
                    $this->session->set_flashdata('update_success_msg', 'Updated successfully !!');
                } else {
                    $this->session->set_flashdata('update_failure_msg', 'Updated successfully !!');
                }
            }else{
                $data_array = array(
                    'group_name'   => ucwords($this->input->post('group_name')),
                    'is_active' => '1',
                    'modified_by'  => $this->session->email,
                    'created_at'   => date("Y-m-d H:i:s",time()),
                    'updated_at'   => date("Y-m-d H:i:s",time())
                );
                $id = $this->common_model->data_insert($data['table'], $data_array);
                if ($id) {
                    $this->session->set_flashdata('insertion_success_msg', 'Created successfully !!');
                } else {
                    $this->session->set_flashdata('insertion_error_msg', 'Error while creating !!');
                }
            }
            redirect($this->trigger);
        }

        $data['title'] 			= 	'Add User Group';
		$data['option_mode']    =   'add';
		if($id)
		{
			$data['title'] 			= 	'Edit User Group';
			$data['option_mode']    =   'edit';
			$data['results']		= 	$this->common_model->data_select_record($data['table'], ['id' => $id]);
		}		
		$this->load->view('groups/edit', $data);
    }

    public function bulkAdd()
    {
        $data = array();
		$data['title'] 	 = $this->title;
		$data['trigger'] = $this->trigger;
        $data['table']	 = $this->table;

        if($this->input->post('submit-btn')){
            $this->load->helper('file');
            #Setting the Rules
            $this->form_validation->set_rules('csvfile', 'CSV File', 'trim|callback_file_check_csv');
            $this->form_validation->set_error_delimiters('<div style="color:red">', '</div>');
            if($this->form_validation->run()){
                $this->load->library('upload');
                $config['upload_path'] = './files/';
                $config['allowed_types'] = 'csv';
                $config['max_size'] = 1024;
                $config['overwrite'] = TRUE;
                $config['encrypt_name'] = TRUE;
                $config['max_filename'] = 25;
                $this->upload->initialize($config);
                if (!$this->upload->do_upload('csvfile')){
                    $this->upload->display_errors();
                }else{
                    $csv = $this->upload->file_name;
                    $arrResult = array();
                    $handle = fopen('./files/'.$csv, "r");
                    if ($handle) {
                        while (($row = fgetcsv($handle, 5000, ",")) !== FALSE) {
                            $arrResult[] = $row;
                        }
                        fclose($handle);
                    }
                    
                    $titles = array_shift($arrResult);
                    foreach ($arrResult as $key => $value) {
                        $data_array['group_name'] = isset($value[0]) ? ucwords(trim($value[0])) : '';
                        $data_array['is_active'] = '1';
                        $data_array['modified_by']  = $this->session->email;
                        $data_array['created_at'] = date("Y-m-d H:i:s",time());
                        $data_array['updated_at'] = date("Y-m-d H:i:s",time());
                        
                        $id = $this->common_model->data_select_record($data['table'], ['group_name' => ucwords(trim($value[0]))]);
                        if($id){
                            $id = $id->id;
                            unset($data_array['created_at']);
                            $update = $this->common_model->data_update($data['table'], $data_array, ['id' => $id]);
                            continue;
                        }else{
                            $ins_id = $this->common_model->data_insert($data['table'], $data_array);
                        }
                    }

                    $file = './files/'.$csv;
                    if (file_exists($file)) {
                        chmod($file,0644);
                        unlink($file);
                    }
                    #To display the error message in next Server request only.
                    $this->session->set_flashdata('bulk_insertion_success_msg', 'User registration Successful.');
                    redirect($this->trigger);
                }
            }
        }

        $data['title'] 	 = 	'Add Bulk User Group';
        $this->load->view('groups/bulk-add',$data);
    } 

    public function delete($id = 0)
	{
        $rows_count = $this->common_model->data_count_record('users', ['usr_group' => $id]);
        if($rows_count == 0){
            $delete = $this->common_model->data_delete($this->table, ['id' => $id]);
            if ($delete) {
                $this->session->set_flashdata('user_delete_success', 'deleted successfully !!');
            } else {
                $this->session->set_flashdata('user_delete_error', 'deleted successfully !!');
            }
        }else{
            $this->session->set_flashdata('user_delete_error', 'deleted successfully !!');
        }
		redirect($this->trigger);
    }
    
    public function bulkDelete()
    {
        $rows = $this->input->get('rows');
        for ($i=0; $i < count($rows); $i++) { 
            $rows_count = $this->common_model->data_count_record('users', ['usr_group' => $rows[$i]]);
            if($rows_count == 0){
                $delete = $this->common_model->data_delete($this->table, ['id' => $rows[$i]]);
            }
        }
        echo "User Delete Successful";
    }

    public function status($id = 0)
	{
		$data = array();
        $status = $this->common_model->change_status($this->table, 'id', $id);
        if($status){
            $this->session->set_flashdata('user_status_success', 'Status has been changed successfully !!');
        }else{
            $this->session->set_flashdata('user_status_error', 'Status has been changed successfully !!');
        }
        redirect($this->trigger);
    }
    
    public function statusBulk()
    {   
        $status = $this->input->get('status');
        $rows = $this->input->get('rows');
        for ($i=0; $i < count($rows); $i++) { 
            $this->common_model->change_status_bulk($this->table, $status, 'id', $rows[$i]);
        }
        echo "Status Update Successful";
    }

    // public function groupRights($user_id = 0){
	// 	$data = array();
	// 	if($this->input->post('saveuserrignts') == 'set_right')
	// 	{
	// 		$user_id = $this->input->post('user_id');
	// 		$this->db->delete('user_rights', array('user_id'	=> $user_id));
	// 		foreach($this->input->post() as $key => $value){
	// 			if(is_array($value)){
	// 				foreach($value as $k=>$val){
	// 					$user_details = array('user_id'			=> $user_id,
	// 										  'menu'			=> $key,
	// 										  'action'			=> $val,
	// 										 );
	// 					$this->common_model->dbinsert('user_rights', $user_details);
	// 				}
	// 			}
	// 		}
	// 		$this->session->set_flashdata('success', 'User Right has been updated successfully !!');
	// 		redirect('admin/users/users');
	// 	}
	// 	$data['title'] 			= 	$this->title;
	// 	$data['userdata']		= 	$this->common_model->select_record('users', 'user_id', $user_id);
	// 	$this->load->view('groups/group_rights', $data);
	// }

    /*
     * file value and type check during validation
    */
	public function file_check_csv($str){
		//$allowed_mime_type_arr = array('application/pdf','image/gif','image/jpeg','image/pjpeg','image/png','image/x-png');
		$allowed_mime_type_arr = array('text/csv');
        $mime = get_mime_by_extension($_FILES['csvfile']['name']);
        if(isset($_FILES['csvfile']['name']) && $_FILES['csvfile']['name']!=""){
            //if(in_array($mime, $allowed_mime_type_arr)){
				if($_FILES['csvfile']['size'] > 1000000 ){
					$this->form_validation->set_message('file_check_csv', 'Please select file of size less than 1MB.');
                	return false;
				}else{
					return true;
				}	
			// }else{
            //     $this->form_validation->set_message('file_check_csv', 'Please select only csv file.');
            //     return false;
            // }
        }else{
            $this->form_validation->set_message('file_check_csv', 'Please choose a file to upload.');
            return false;
        }
    }
}
        
    /* End of file  Groups.php */
        
                            