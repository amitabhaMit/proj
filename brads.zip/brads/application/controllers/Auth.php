<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends MY_controller {
	
	protected $title = 'login';
	
	public function __construct()
	{
		parent::__construct();
	}
	
    public function index()
    {
		
        if ($this->session->userdata('user_id')) {
            redirect($this->session->flashdata('last_page'));
        } else {		
            if ($this->input->post('loginbtn')) {
                #Setting the Rules
                $this->form_validation->set_rules('usr_email', 'E-Mail Id.', 'trim|required');
                $this->form_validation->set_rules('password', 'Password', 'trim|required');
                $this->form_validation->set_rules('logtype', 'User Type', 'trim|required');
                $this->form_validation->set_rules('fin_year', 'Financial Year', 'trim|required');
                $this->form_validation->set_error_delimiters('<div style="color:red">', '</div>');
                if ($this->form_validation->run()) {
					//echo ($this->input->post('usr_email'). ', '.$this->input->post('password'). ', '.$this->input->post('logtype'). ', '.$this->input->post('fin_year'));
					//die();
                    $user_data = array(
                        'usr_email' => $this->input->post('usr_email'),
                        'usr_password' => $this->input->post('password'),
                        'logtype' => $this->input->post('logtype'),
                        'fin_year' => $this->input->post('fin_year')						
                    );
                    $output = $this->_loginAuth($user_data);
                    if ($output != "TRUE") {
                        $data = array();
                        $data['title'] = $this->title;
                        //$data['type'] = 'login';
                        $data['logo']    = $this->common_model->data_get_siteconfig('logo');
                        $this->session->set_flashdata('error_msg', $output);
                        $this->load->view('/auth/login', $data);
                    } else {
                        $log_data = array(
                            'log_user' => $this->session->userdata('name'),
                            'log_session_id' => $this->session->session_id,
                            'log_ip_address' => $this->input->ip_address(),
                            'login_time' => date("Y-m-d H:i:s", time()),
                            'logout_time' => date("Y-m-d H:i:s", time())
                        );
                        //$this->_setAuthLog($log_data);
                        $this->session->set_flashdata('success_msg', 'Welcome ' . $this->session->name);
                        redirect($this->input->post('url'));
                    }
                }
            }
            $data = array();
            $data['title'] = $this->title;
            //$data['type'] = 'login';
            $data['logo']   		= 	$this->common_model->data_get_siteconfig('logo');
			$data['results']		= 	$this->common_model->data_select('user_group', false, ['is_active' => '1'], 'id');
            $this->load->view('/auth/login', $data);
        }
    }  

    private function _loginAuth($data)
    {		
        $this->load->helper('phpass');
        $hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);
        $get_user = $this->common_model->data_select('users', true, ['usr_email' => $data['usr_email']]);
        if ($get_user) {
            if ($get_user[0]["is_active"] != 1) {
                return "User Status Inactive. Contact to Admin.";
            }else if ($get_user[0]["usr_group"] != $data['logtype']) {
                return "User Type Mismatch. Contact to Admin.";
            } else {
                if ($hasher->CheckPassword($data['usr_password'], $get_user[0]["usr_password"])) {
					/*if (date('m') <= 4) {//Upto April 2019-2020
						$year = (date('Y')-1);
					} else {//After April 2019-2020
						$year = date('Y')-1;
					}*/
                    $sessionData = array(
                        'name'        => $get_user[0]["usr_fullname"],
                        'email'       => $get_user[0]["usr_email"],
						'usr_contact' => $get_user[0]["usr_contact"],
                        'user_id'     => $get_user[0]["id"],
                        'user_group'  => $get_user[0]["usr_group"],
						'fin_year'    => $data['fin_year'],
                        'is_loggedin' => true
                    );
                    $this->session->set_userdata($sessionData);
                    return "TRUE";
                } else {
                    return "Invalid Password. Try again.";
                }
            }
        } else {
            return "User with this E-Mail ID does not exsist.";
        }
    }
    private function _setAuthLog($data)
    {
        $this->common_model->data_insert('auth_log', $data);
    }
	

	
    public function logout()
    {
        //echo "Hello";
        $log_data = array(
            'logout_time' => date("Y-m-d H:i:s", time())
        );
        //$this->_setAuthLogOut($log_data, $this->session->session_id);
        $array_items = array('name', 'email', 'user_id', 'user_group', 'is_loggedin');
        $this->session->unset_userdata($array_items);
        redirect('/');
    }
    private function _setAuthLogOut($data, $sessId)
    {
        return $this->common_model->data_update('auth_log',$data,['log_session_id' => $sessId]);
    }   
}
        
    /* End of file  Auth.php */
	

?>