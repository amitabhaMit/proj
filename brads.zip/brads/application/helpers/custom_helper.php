<?php
function is_logged_in()
{
    $CI = &get_instance();
    $is_logged_in = $CI->session->userdata('user_id');
    if (!isset($is_logged_in) || $is_logged_in != true) {
        redirect(base_url() . 'login');
    }
    $CI->session->set_flashdata('last_page', current_url());
}
function get_siteconfig($key)
{
    $CI = &get_instance();
    $setting = $CI->common_model->data_get_siteconfig($key);
    $img_src = false;
    if ($key == 'logo') {
        $logo = $CI->common_model->data_get_siteconfig('logo');
        if ($logo != '') {
            $img_src = base_url() . UPLOADSDIR . $logo;
        }
        return $img_src;
    }
    if ($key == 'favicon') {
        $logo = $CI->common_model->data_get_siteconfig('favicon');
        if ($logo != '') {
            $img_src = base_url() . UPLOADSDIR . $logo;
        }
        return $img_src;
    }
    return $setting;
}

function get_user_rgt($user_group, $menu, $action)
{
    if($user_group == '1'){
        return true;
    }else{
        return false;
    }
    //return $this->db_select_admin_users_rights($user_group, $menu, $action);
}

function generateSequenceNo($prefix = "", $suffix = "", $tableName, $columnName)
{
    $CI = get_instance();

    $CI->db->select_max($columnName);
    $CI->db->from($tableName);
    $results = $CI->db->get()->row();
    if ($results->$columnName == '') {
        $last_id = 0;
    } else {
        $last_id = $results->$columnName;
    }
    
    $orderNo = ++$last_id;
	
	return $prefix.str_pad($orderNo, 0, '0', STR_PAD_LEFT).$suffix;
} 
function getDataById($table_name, $id, $field_name)
{
    $CI = get_instance();
    // $result = $CI->common_model->data_select_record($table_name, ['id' => $id]);
    // if($result){
    //     return $result->field_name;
    // }else{
    //     return false;
    // }
    return $CI->common_model->data_select_record($table_name, ['id' => $id])->$field_name;
}
/* End of file Custom.php */
