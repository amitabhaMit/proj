<!doctype html>
<html lang="en">

<head>
    <title><?php echo $title; ?> | <?php echo get_siteconfig('website_name'); ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <?php $this->load->view('includes/header-styles.php'); ?>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/bootstrap-datepicker/css/bootstrap-datepicker3.min.css?<?php echo date('d:m:y:h:i:s'); ?>">
    <style>
	.file-upload {
 width: 600px;
 margin: 0 auto;
 padding: 20px;
}
.file-upload-btn {
 width: 100%;
 margin: 0;
 color: #fff;
 background: #1FB264;
 border: none;
 padding: 10px;
 border-radius: 4px;
 border-bottom: 4px solid #15824B;
 transition: all .2s ease;
 outline: none;
 text-transform: uppercase;
 font-weight: 700;
}
.file-upload-btn:hover {
 background: #1AA059;
 color: #ffffff;
 transition: all .2s ease;
 cursor: pointer;
}
.file-upload-btn:active {
 border: 0;
 transition: all .2s ease;
}
.file-upload-content {
 display: none;
 text-align: center;
}
.file-upload-input {
 position: absolute;
 margin: 0;
 padding: 0;
 width: 100%;
 height: 100%;
 outline: none;
 opacity: 0;
 cursor: pointer;
}
.image-upload-wrap {
 margin-top: 20px;
 border: 4px dashed #1FB264;
 position: relative;
}
.image-dropping,
.image-upload-wrap:hover {
 background-color: #1FB264;
 border: 4px dashed #ffffff;
}
.image-title-wrap {
 padding: 0 15px 15px 15px;
 color: #222;
}
.drag-text {
 text-align: center;
}
.drag-text h3 {
 font-weight: 100;
 text-transform: uppercase;
 color: #15824B;
 padding: 60px 0;
}
.image-upload-wrap:hover .drag-text h3 {
color: #fff;
}
.file-upload-image {
 max-height: 200px;
 max-width: 200px;
 margin: auto;
 padding: 20px;
}
.remove-image {
 width: 200px;
 margin: 0;
 color: #fff;
 background: #cd4535;
 border: none;
 padding: 10px;
 border-radius: 4px;
 border-bottom: 4px solid #b02818;
 transition: all .2s ease;
 outline: none;
 text-transform: uppercase;
 font-weight: 700;
}
.remove-image:hover {
 background: #c13b2a;
 color: #ffffff;
 transition: all .2s ease;
 cursor: pointer;
}
.remove-image:active {
 border: 0;
 transition: all .2s ease;
}
	</style>
</head>

<body class="theme-blue">
    <?php $this->load->view('includes/preloader.php'); ?>
    <div id="wrapper">
        <?php $this->load->view('includes/header-menu.php'); ?>
        <?php $this->load->view('includes/sidebar-menu.php'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><?php echo $title; ?></h2>
                        </div>
                        <div class="col-lg-7 col-md-4 col-sm-12 text-right">
                            <ul class="breadcrumb justify-content-end">
                                <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item active"><?php echo $title; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="header">
                                <h2><?php echo $title; ?></h2>
                            </div>
                            <div class="body">
                                <?php
                                $action_url = isset($results->id) ? "/".$results->id : '';
                                $action_url = site_url($trigger.'edit').$action_url;
                                ?>
                                <?php echo form_open_multipart($action_url, ['class' => "form-auth-small", 'id' => "basic-form"]); ?>
                                <input type="hidden" value="<?php echo isset($results->id) ? $results->id : '' ;?>" name="id"/>
                                <div class="row clearfix">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label for="usr_fullname" class="control-label">Full Name</label>
                                            <input type="text" id="usr_fullname" class="form-control <?php if (form_error('usr_fullname') != '') { echo "parsley-error"; } ?>" name="usr_fullname" placeholder="Full Name" value="<?php echo isset($results->usr_fullname) ? $results->usr_fullname : '' ;?>" autofocus required>
                                            <?php if (form_error('usr_fullname') != '') { ?>
                                                <ul class="parsley-errors-list filled">
                                                    <li class="parsley-required"><?php echo form_error('usr_fullname'); ?></li>
                                                </ul>
                                            <?php } ?>
                                        </div>
                                    </div> 
									<div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label for="usr_email" class="control-label">Email</label>
                                            <input type="email" id="usr_email" class="form-control <?php if (form_error('usr_email') != '') { echo "parsley-error"; } ?>" name="usr_email" placeholder="Email" value="<?php echo isset($results->usr_email) ? $results->usr_email : '' ;?>" onchange="javascript:email_validate(this.value)" required>
                                            <?php if (form_error('usr_email') != '') { ?>
                                                <ul class="parsley-errors-list filled">
                                                    <li class="parsley-required"><?php echo form_error('usr_email'); ?></li>
                                                </ul>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12">
											<div class="form-group">
												<label for="invoicedate" class="control-label">Registration Date</label>
												<input type="text" tabindex="4" id="invoicedate" class="form-control <?php if (form_error('invoicedate') != '') { echo "parsley-error"; } ?>" name="invoicedate" data-provide="datepicker" data-date-autoclose="true"  data-date-format="dd/mm/yyyy" placeholder="Invoice Date" value="<?php echo date("d/m/Y"); ?>" required>
												<!--<input data-provide="datepick er" data-date-autoclose="true" class="form-control" data-date-format="dd/mm/yyyy">	-->											

											</div>
									</div>
                                    <div class="col-lg-12 col-md-12 col-sm-12">
										<div class="file-upload">
                                        <label for="invoicedate" class="control-label">Upload Image (Within 20KB):</label>
											<div class="image-upload-wrap">
												<input class="file-upload-input" type='file' name="image[]" multiple="multiple" onchange="readURL(this);" accept="image/*" />
												<div class="drag-text">
													<h3>Drag and drop a file or select add Image</h3>
												</div>
											</div>
                                            <?php 
                                            if ( ( ($option_mode == 'view') || ($option_mode == 'edit') ) && ($results->i_image!="") ) {
                                                $old_img_arr = unserialize($results->i_image);
                                                foreach($old_img_arr as $value){
                                            ?>
                                                <div class="">
                                                <img class="file-upload-image" class="remove-image" src="<?php echo "http://localhost/brads/inward/".$value;?>" alt="your image" />
                                                </div>
                                            <?php		
                                                }
                                            }
                                            ?>													
												
											<div class="image-title-wrap" style="display:none;">
												<center><button type="button" onclick="removeUpload()" class="remove-image" tabindex="10">Remove <span class="image-title">Uploaded Image</span></button></center>
											</div> 
									   </div>
								   </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label for="usr_contact" class="control-label">Contact No</label>
                                            <input type="text" id="usr_contact" class="form-control <?php if (form_error('usr_contact') != '') { echo "parsley-error"; } ?>" name="usr_contact" placeholder="Contact No" value="<?php echo isset($results->usr_contact) ? $results->usr_contact : '' ;?>" onchange="javascript:cont_validate(this.value)" required>
                                            <?php if (form_error('usr_contact') != '') { ?>
                                                <ul class="parsley-errors-list filled">
                                                    <li class="parsley-required"><?php echo form_error('usr_contact'); ?></li>
                                                </ul>
                                            <?php } ?>
                                        </div>
                                    </div> 
                                    <?php if($option_mode == 'add'){ ?>
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label for="usr_password" class="control-label">Password</label>
                                            <input type="password" id="usr_password" class="form-control <?php if (form_error('usr_password') != '') { echo "parsley-error"; } ?>" name="usr_password" placeholder="User Password" value="<?php echo isset($results->usr_password) ? $results->usr_password : '' ;?>" required>
                                            <?php if (form_error('usr_password') != '') { ?>
                                                <ul class="parsley-errors-list filled">
                                                    <li class="parsley-required"><?php echo form_error('usr_password'); ?></li>
                                                </ul>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label for="usr_password" class="control-label">Confirm Password</label>
                                            <input type="password" id="con_password" class="form-control <?php if (form_error('usr_password') != '') { echo "parsley-error"; } ?>" name="con_password" placeholder="Confirm Password" value="" required>
                                            <?php if (form_error('usr_password') != '') { ?>
                                                <ul class="parsley-errors-list filled">
                                                    <li class="parsley-required"><?php echo form_error('usr_password'); ?></li>
                                                </ul>
                                            <?php } ?>
                                        </div>
                                    </div>    
    
                                    <?php } ?>  
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label for="usr_group" class="control-label">User Type</label>
                                            <div class="multiselect_div">
                                                <select id="usr_group" name="usr_group" class="multiselect multiselect-custom">
                                                    <?php $selected_id = isset($results->usr_group) ? $results->usr_group : false; ?>
                                                    <?php echo $this->common_model->data_get_select_option_where_clause('user_group', 'id', 'group_name', $selected_id, ['is_active' => '1'], 'group_name'); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div> 
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="float-right">
                                            <?php if($option_mode != 'view'){ ?>
                                            <input type="submit" name="submit-btn" class="btn btn-primary" value="<?php if($option_mode == 'add'){ echo "Submit"; }else{ echo "Update"; }?>">
                                            <?php } ?>
                                            <a href="<?php echo base_url($trigger); ?>" class="btn btn-danger"><?php if($option_mode == 'view'){ echo "Go Back"; }else{ echo "Cancel"; }?></a>
                                        </div>
                                    </div>
									
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $this->load->view('includes/footer-scripts.php'); ?>
    <script src="<?php echo base_url();?>assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js?<?php echo date('d:m:y:h:i:s'); ?>"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js'></script>
    <script src="<?php echo base_url();?>assets/vendor/ckeditor/ckeditor.js"></script>
    <!-- Ckeditor -->
    <script src="<?php echo base_url();?>assets/js/pages/forms/editors.js"></script>

    <?php if($option_mode == 'view'){ ?> 
        <script>
        $(document).ready(function () {
            $('#basic-form *').attr('disabled', 'disabled');
        });
        </script>
    <?php } ?>
   
   <script>
        $(document).ready(function () {
            $('#usr_group').multiselect({
                enableFiltering: true,
                enableCaseInsensitiveFiltering: true,
                maxHeight: 200
            });

            $("#basic-form").on('submit', function(e){
                //e.preventDefault();
                var pwd_val = $('#usr_password').val();
                var pwd_con_val = $('#con_password').val();

                if (pwd_val != pwd_con_val){
                    alert('Password & Confirm Password not same');
                    return false;
                }else{
                    //$("#basic-form").submit();
                    return true;    
                }


            });
        });
    </script>					
	<script type="text/javascript">
	
		function name_validate(value){
			if (value.length==0){
				alert("Full Name should not be blank!")
				return false
			}else {
				return true
			}
		};					

		function email_validate(value){
			if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(value)){
				return true
			}else {
				alert("Invalid E-Mail Id!")
				return false
			}
		};					
		function cont_validate(value){	
			if (value.length>11){
				alert("Contact No. should contain maximum 11 digits!")
				return false
			}else {
				return true
			}
		};					
					
					
	</script>

    <script type="text/javascript">
        function readURL(input) {
            if (input.files && input.files.length) {
                //console.log('A: '+input.files+' B: '+input.files.length);
                for( var i=0; i<input.files.length ;i++){
                    var reader = new FileReader();
                
                    reader.onload = function(e) {
                        $('.image-upload-wrap').hide();
            
                        //$('.file-upload-image').attr('src', e.target.result);
                        //$().appand("<img class='file-upload-image' src='#' alt='your image' />")
                        $('.file-upload-content').append("<img class='file-upload-image' src='"+e.target.result+"'><br>");
                        $('.file-upload-content').show();
                        $('.image-title-wrap').show();
            
                        //$('.image-title').html(input.files[0].name);
                    };
                    //console.log('C: '+ input.files[i].size);
                    if (input.files[i].size > 20000) {
                        alert("Try to upload file less than 20KB!");
                    } else {
                        reader.readAsDataURL(input.files[i]);
                    }
                }
                
        
            } else {
                removeUpload();
            }
        }
        
        function removeUpload() {
            $('.file-upload-input').replaceWith($('.file-upload-input').clone());
            $('.file-upload-content').empty();
            $('.file-upload-content').hide();
            $('.image-title-wrap').hide();
            $('.image-upload-wrap').show();
        }

        $('.image-upload-wrap').bind('dragover', function() {
            $('.image-upload-wrap').addClass('image-dropping');
        });
        $('.image-upload-wrap').bind('dragleave', function() {
            $('.image-upload-wrap').removeClass('image-dropping');
        });		

			
						
	</script>
	<script src="<?php echo base_url();?>assets/js/jquery.ui.widget.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.iframe-transport.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.fileupload.js"></script> 
</body>

</html>