<!doctype html>
<html lang="en">

<head>
    <title><?php echo $title; ?> | <?php echo get_siteconfig('website_name'); ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <?php $this->load->view('includes/header-styles.php'); ?>
    <?php $this->load->view('includes/datatables-styles.php'); ?>
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/toastr/toastr.min.css">
</head>

<body class="theme-blue">
    <?php $this->load->view('includes/preloader.php'); ?>
    <div id="wrapper">
        <?php $this->load->view('includes/header-menu.php'); ?>
        <?php $this->load->view('includes/sidebar-menu.php'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><?php echo $title; ?></h2>
                        </div>
                        <div class="col-lg-7 col-md-4 col-sm-12 text-right">
                            <ul class="breadcrumb justify-content-end">
                                <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i
                                            class="icon-home"></i></a></li>
                                <li class="breadcrumb-item active"><?php echo $title; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <?php if( get_user_rgt($this->session->userdata('user_group'), 'user', 'add') ) { ?>
                                <a href="<?php echo base_url($trigger.'edit');?>" class="btn btn-primary m-b-15 float-right"><i class="icon wb-plus" aria-hidden="true"></i> Add <?php echo $title; ?></a>
                                <?php } ?>
                                <div class="tbl-dropdown float-left" style="position:relative">
                                    <a href="javascript:void(0);"
                                        class="dropdown-toggle icon-menu btn btn-outline-primary"
                                        data-toggle="dropdown">Bulk Action</a>
                                    <ul class="dropdown-menu animated flipInX" style="padding:10px; margin-top:40px;">
                                        <?php if( get_user_rgt($this->session->userdata('user_group'), 'user', 'add') ) { ?>
                                        <li><a href="<?php echo base_url($trigger.'bulkAdd')?>">Add <?php echo $title; ?></a></li>
                                        <?php } ?>
                                        <?php if( get_user_rgt($this->session->userdata('user_group'), 'user', 'edit') ) { ?>
                                        <li><a href="#" class="status-change" data-status="1">Status Active</a></li>
                                        <li><a href="#" class="status-change" data-status="0">Status Inactive</a></li>
                                        <?php } ?>
                                        <?php if( get_user_rgt($this->session->userdata('user_group'), 'user', 'delete') ) { ?>
                                        <li><a href="#" class="delete-bulk">Delete</a></li>
                                        <?php } ?>
                                    </ul>
                                </div>
                                <div class="table-responsive">
                                    <table
                                        class="table table-bordered table-striped table-hover dataTable js-exportable">
                                        <thead>
                                            <tr>
                                                <th>
                                                    <label class="fancy-checkbox">
                                                        <input class="select-all" type="checkbox" name="checkbox">
                                                        <span></span>
                                                    </label>
                                                </th>
                                                <th>Name</th>
                                                <th>Email-Id</th>
                                                <th>Contact No.</th>
                                                <th>User Group</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($results){ ?>
                                            <?php foreach ($results as $key => $row) { ?>
                                            <tr>
                                                <td style="width: 50px;">
                                                    <label class="fancy-checkbox">
                                                        <input class="checkbox-tick" type="checkbox" name="selected-row" value="<?php echo $row->id; ?>">
                                                        <span></span>
                                                    </label>
                                                </td>
                                                <td><?php echo $row->usr_fullname; ?></td>
                                                <td><?php echo $row->usr_email; ?></td>
                                                <td><?php echo $row->usr_contact; ?></td>
                                                <td><?php echo getDataById('user_group',$row->usr_group,'group_name'); ?></td>
                                                <td>
                                                    <?php if( get_user_rgt($this->session->userdata('user_group'), 'user', 'edit') ) { ?>
                                                        <?php if($row->is_active == '1'){?>
                                                        <a href="<?php echo base_url($trigger.'status/'.$row->id); ?>" class="btn btn-success btn-round"
                                                            rel="noopener noreferrer">Active</a>
                                                        <?php }else{ ?>
                                                        <a href="<?php echo base_url($trigger.'status/'.$row->id); ?>" class="btn btn-danger btn-round"
                                                            rel="noopener noreferrer">Inactive</a>
                                                        <?php } ?>
                                                    <?php }else{ ?>
                                                        <?php if($row->is_active == '1'){?>
                                                        <a href="#" class="btn btn-success btn-round" rel="noopener noreferrer">Active</a>
                                                        <?php }else{ ?>
                                                        <a href="#" class="btn btn-danger btn-round" rel="noopener noreferrer">Inactive</a>
                                                        <?php } ?>
                                                    <?php } ?>
                                                </td>
                                                <td>
                                                    <?php if( get_user_rgt($this->session->userdata('user_group'), 'users', 'view') ) { ?>
								                        <a href="<?php echo base_url($trigger.'view/'.$row->id); ?>" class="btn btn-sm btn-icon btn-pure btn-default on-default m-r-5 button-edit" data-toggle="tooltip" data-original-title="View"><i class="icon-eye" aria-hidden="true"></i></a>
                                                    <?php } ?>
                                                    <?php if( get_user_rgt($this->session->userdata('user_group'), 'users', 'edit') ) { ?>
                                                        <a href="<?php echo base_url($trigger.'edit/'.$row->id); ?>" class="btn btn-sm btn-icon btn-pure btn-default on-default m-r-5 button-edit" data-toggle="tooltip" data-original-title="Edit" onClick="confirm('Are you want to edit this row?');"><i class="icon-pencil" aria-hidden="true"></i></a>
                                                    <?php } ?>
                                                    <?php if( get_user_rgt($this->session->userdata('user_group'), 'users', 'delete') ) { ?>    
                                                        <a href="<?php echo base_url($trigger.'delete/'.$row->id); ?>" class="btn btn-sm btn-icon btn-pure btn-default on-default m-r-5 button-remove" data-toggle="tooltip" data-original-title="Remove" onClick="confirm('Are you want to delete this row?');"><i class="icon-trash" aria-hidden="true"></i></a>
                                                    <?php } ?>    
                                                </td>
                                            </tr>
                                            <?php } ?>
                                            <?php }else{?>
                                                <tr>
                                                    <td style="width: 50px;"></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>
                                                    <label class="fancy-checkbox">
                                                        <input class="select-all" type="checkbox" name="checkbox">
                                                        <span></span>
                                                    </label>
                                                </th>
                                                <th>Name</th>
                                                <th>Email-Id</th>
                                                <th>Contact No.</th>
                                                <th>User Group</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $this->load->view('includes/footer-scripts.php'); ?>
    <?php $this->load->view('includes/datatables-scripts.php'); ?>
    <script>
        $('.status-change').click(function (e) { 
            e.preventDefault();
            var checkbox = $('.checkbox-tick:checked');
            if(checkbox.length > 0){
                var selected_rows = [];
                $(checkbox).each(function(){
                    selected_rows.push($(this).val());
                });
                var status = $(this).data('status');
                $.ajax({
                    type: "GET",
                    url: "<?php echo base_url($trigger.'statusBulk'); ?>",
                    data: {status:status, rows: selected_rows},
                    dataType: "text",
                    success: function (response) {
                        toastr.remove();
                        toastr['success']('Status updated successfully.', '', {
                            timeOut: 3000,
                            closeButton: true,
                            positionClass: 'toast-top-right'
                        });
                        setTimeout(function(){ location.reload(true); }, 2500);   
                    }
                });
            }else{
                alert('Select atleast one record.');
            }
        });
        $('.delete-bulk').click(function (e) { 
            e.preventDefault();
            var checkbox = $('.checkbox-tick:checked');
            if(checkbox.length > 0){
                var selected_rows = [];
                $(checkbox).each(function(){
                    selected_rows.push($(this).val());
                });
                $.ajax({
                    type: "GET",
                    url: "<?php echo base_url($trigger.'bulkDelete'); ?>",
                    data: {rows: selected_rows},
                    dataType: "text",
                    success: function (response) {
                        toastr.remove();
                        toastr['success']('Users deleted successfully.', '', {
                            timeOut: 3000,
                            closeButton: true,
                            positionClass: 'toast-top-right'
                        });
                        setTimeout(function(){ location.reload(true); }, 2500);   
                    }
                });
            }else{
                alert('Select atleast one record.');
            }
        });
    </script>
    <script src="<?php echo base_url(); ?>assets/vendor/toastr/toastr.js"></script>
    <?php if($this->session->flashdata('insertion_success_msg')){ ?>
        <script>
            $(function () {
                toastr.remove();
                toastr['success']('User added Successfully.', '', {
                    timeOut: 3000,
                    closeButton: true,
                    positionClass: 'toast-top-right'
                });
            });
        </script>
    <?php } ?>
    <?php if($this->session->flashdata('insertion_error_msg')){ ?>
        <script>
            $(function () {
                toastr.remove();
                toastr['error']('User not added. Please Try again later.', '', {
                    timeOut: 3000,
                    closeButton: true,
                    positionClass: 'toast-top-right'
                });
            });
        </script>
    <?php } ?>
    <?php if($this->session->flashdata('update_success_msg')){ ?>
        <script>
            $(function () {
                toastr.remove();
                toastr['success']('User updated Successfully.', '', {
                    timeOut: 3000,
                    closeButton: true,
                    positionClass: 'toast-top-right'
                });
            });
        </script>
    <?php } ?>
    <?php if($this->session->flashdata('update_failure_msg')){ ?>
        <script>
            $(function () {
                toastr.remove();
                toastr['error']('User not updated. Please Try again later.', '', {
                    timeOut: 3000,
                    closeButton: true,
                    positionClass: 'toast-top-right'
                });
            });
        </script>
    <?php } ?>
    <?php if($this->session->flashdata('user_status_success')){ ?>
        <script>
            $(function () {
                toastr.remove();
                toastr['success']('User status updated successfully.', '', {
                    timeOut: 3000,
                    closeButton: true,
                    positionClass: 'toast-top-right'
                });
            });
        </script>
    <?php } ?>
    <?php if($this->session->flashdata('user_status_error')){ ?>
        <script>
            $(function () {
                toastr.remove();
                toastr['error']('User status not updated. Please Try again later.', '', {
                    timeOut: 3000,
                    closeButton: true,
                    positionClass: 'toast-top-right'
                });
            });
        </script>
    <?php } ?>
    <?php if($this->session->flashdata('user_delete_success')){ ?>
        <script>
            $(function () {
                toastr.remove();
                toastr['success']('User deleted successfully.', '', {
                    timeOut: 3000,
                    closeButton: true,
                    positionClass: 'toast-top-right'
                });
            });
        </script>
    <?php } ?>
    <?php if($this->session->flashdata('user_delete_error')){ ?>
        <script>
            $(function () {
                toastr.remove();
                toastr['error']('User is not deleted succesfully. Please try again.', '', {
                    timeOut: 3000,
                    closeButton: true,
                    positionClass: 'toast-top-right'
                });
            });
        </script>
    <?php } ?>
</body>

</html>