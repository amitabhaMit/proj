<!doctype html>
<html lang="en">

<head>
    <title><?php echo $title; ?> | <?php echo get_siteconfig('website_name'); ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <?php $this->load->view('includes/header-styles.php'); ?>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/bootstrap-datepicker/css/bootstrap-datepicker3.min.css?<?php echo date('d:m:y:h:i:s'); ?>">
</head>

<body class="theme-blue">
    <?php $this->load->view('includes/preloader.php'); ?>
    <div id="wrapper">
        <?php $this->load->view('includes/header-menu.php'); ?>
        <?php $this->load->view('includes/sidebar-menu.php'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><?php echo $title; ?></h2>
                        </div>
                        <div class="col-lg-7 col-md-4 col-sm-12 text-right">
                            <ul class="breadcrumb justify-content-end">
                                <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item active"><?php echo $title; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="header">
                                <h2><?php echo $title; ?></h2>
                            </div>
                            <div class="body">
                                <?php
                                $action_url = isset($results->id) ? "/".$results->id : '';
                                $action_url = site_url($trigger.'password').$action_url;
                                ?>
                                <?php echo form_open_multipart($action_url, ['class' => "form-auth-small", 'id' => "basic-form"]); ?>
                                <input type="hidden" value="<?php echo isset($results->id) ? $results->id : '' ;?>" name="id"/>
                                <div class="row clearfix">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label for="usr_password" class="control-label">New Password</label>
                                            <input type="password" id="usr_password" class="form-control <?php if (form_error('usr_password') != '') { echo "parsley-error"; } ?>" name="usr_password" placeholder="New Password" value="" required>
                                            <?php if (form_error('usr_password') != '') { ?>
                                                <ul class="parsley-errors-list filled">
                                                    <li class="parsley-required"><?php echo form_error('usr_password'); ?></li>
                                                </ul>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label for="confirm_password" class="control-label">Confirm Password</label>
                                            <input type="password" id="confirm_password" class="form-control <?php if (form_error('confirm_password') != '') { echo "parsley-error"; } ?>" name="confirm_password" placeholder="Confirm Password" value="" required>
                                            <?php if (form_error('confirm_password') != '') { ?>
                                                <ul class="parsley-errors-list filled">
                                                    <li class="parsley-required"><?php echo form_error('confirm_password'); ?></li>
                                                </ul>
                                            <?php } ?>
                                        </div>
                                    </div>    
                                    <div class="col-lg-12 col-md-6 col-sm-12">
                                        <div class="float-right">
                                            <input type="submit" name="submit-btn" class="btn btn-primary" value="Update">
                                            <a href="<?php echo base_url($trigger); ?>" class="btn btn-danger">Cancel</a>
                                        </div>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $this->load->view('includes/footer-scripts.php'); ?>
    <script src="<?php echo base_url();?>assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js?<?php echo date('d:m:y:h:i:s'); ?>"></script>
    <script>
        $(document).ready(function () {
            $('#usr_group').multiselect({
                enableFiltering: true,
                enableCaseInsensitiveFiltering: true,
                maxHeight: 200
            });
        });
    </script>    
</body>

</html>