<!doctype html>
<html lang="en">

<head>
    <title><?php echo $title; ?> | <?php echo get_siteconfig('website_name'); ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <?php $this->load->view('includes/header-styles.php'); ?>
</head>

<body class="theme-blue">
    <?php $this->load->view('includes/preloader.php'); ?>
    <div id="wrapper">
        <?php $this->load->view('includes/header-menu.php'); ?>
        <?php $this->load->view('includes/sidebar-menu.php'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><?php echo $title; ?></h2>
                        </div>
                        <div class="col-lg-7 col-md-4 col-sm-12 text-right">
                            <ul class="breadcrumb justify-content-end">
                                <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item active"><?php echo $title; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="header">
                                <h2><?php echo $title; ?></h2>
                            </div>
                            <div class="body">
                                <?php
                                $action_url = isset($results->id) ? "/".$results->id : '';
                                $action_url = site_url($trigger.'edit').$action_url;
                                ?>
                                <?php echo form_open_multipart($action_url, ['class' => "form-auth-small", 'id' => "basic-form"]); ?>
                                <input type="hidden" value="<?php echo isset($results->id) ? $results->id : '' ;?>" name="id"/>
                                <div class="row clearfix">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label for="group_name" class="control-label">Group Name</label>
                                            <input type="text" id="group_name" class="form-control <?php if (form_error('group_name') != '') { echo "parsley-error"; } ?>" name="group_name" placeholder="Group Name" value="<?php echo isset($results->group_name) ? $results->group_name : '' ;?>" autofocus required>
                                            <?php if (form_error('group_name') != '') { ?>
                                                <ul class="parsley-errors-list filled">
                                                    <li class="parsley-required"><?php echo form_error('group_name'); ?></li>
                                                </ul>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-6 col-sm-12">
                                        <div class="float-right">
                                            <input type="submit" name="submit-btn" class="btn btn-primary" value="<?php if($option_mode == 'add'){ echo "Submit"; }else{ echo "Update"; }?>">
                                            <a href="<?php echo base_url($trigger); ?>" class="btn btn-danger">Cancel</a>
                                        </div>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $this->load->view('includes/footer-scripts.php'); ?>
</body>

</html>