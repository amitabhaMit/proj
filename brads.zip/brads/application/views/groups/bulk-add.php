<!doctype html>
<html lang="en">

<head>
    <title><?php echo $title; ?> | <?php echo get_siteconfig('website_name'); ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <?php $this->load->view('includes/header-styles.php'); ?>
</head>

<body class="theme-blue">
    <?php $this->load->view('includes/preloader.php'); ?>
    <div id="wrapper">
        <?php $this->load->view('includes/header-menu.php'); ?>
        <?php $this->load->view('includes/sidebar-menu.php'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><?php echo $title; ?></h2>
                        </div>
                        <div class="col-lg-7 col-md-4 col-sm-12 text-right">
                            <ul class="breadcrumb justify-content-end">
                                <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item active"><?php echo $title; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="header">
                                <h2><?php echo $title; ?></h2>
                            </div>
                            <div class="body">
                                <a href="<?php echo base_url('/assets/csv/sample_'.	rtrim($trigger,'/').'.csv'); ?>" class="btn btn-primary m-b-15 float-right"><i class="fa fa-download"
                                        aria-hidden="true"></i> Download Sample File</a>
                                <p>The first line in downloaded csv file should remain as it is. Please do not change the order of columns.</p>
                                <p>The correct column order is (User Group) & you must follow this.
                                Please make sure the csv file is UTF-8 encoded and not saved with byte order mark (BOM).</p>
                                <p>System will check if the sheet belong to any user then will update that user otherwise will add new user.</p>
                                <?php echo form_open_multipart($trigger.'bulkAdd', ['class' => "form-auth-small", 'id' => "basic-form", ]); ?>
                                <div class="row clearfix">
                                    <div class="input-group col-lg-12 col-md-12 col-sm-12 mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">Upload File*</span>
                                        </div>
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" name="csvfile" id="csvfile">
                                            <label class="custom-file-label" for="csvfile">Choose file</label>
                                        </div>
                                    </div> 
                                    <?php echo form_error('csvfile'); ?>
                                    <div class="col-lg-12 col-md-6 col-sm-12">
                                        <div class="float-right">
                                            <input type="submit" name="submit-btn" class="btn btn-primary" value="Submit">
                                            <a href="<?php echo base_url($trigger); ?>" class="btn btn-danger">Cancel</a>
                                        </div>
                                    </div>   
                                </div>    
                                <?php echo form_close(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $this->load->view('includes/footer-scripts.php'); ?>
</body>

</html>