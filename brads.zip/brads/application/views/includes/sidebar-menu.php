<div id="leftsidebar" class="sidebar">
    <div class="sidebar-scroll">
        <nav id="leftsidebar-nav" class="sidebar-nav">
            <ul id="main-menu" class="metismenu">
                <li class="heading">Main</li>
                <li class="<?php if($this->uri->segment(1) == 'dashboard'){ echo "active";}?>"><a href="<?php echo base_url('/dashboard'); ?>"><i class="icon-home"></i><span>Dashboard</span></a></li>
                <li class="heading">Mastar Data</li>
                <li class="<?php if($this->uri->segment(1) == 'groups'){ echo "active";}?>"><a href="<?php echo base_url('/groups'); ?>"><i class="icon-users"></i><span>User Groups</span></a></li>
                <li class="<?php if($this->uri->segment(1) == 'users'){ echo "active";}?>"><a href="<?php echo base_url('/users'); ?>"><i class="icon-user"></i><span>Users</span></a></li>
				
            </ul>
        </nav>
    </div>
    
</div>