<link rel="icon" href="<?php echo get_siteconfig('favicon'); ?>" type="image/x-icon">
<!-- VENDOR CSS -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/bootstrap/css/bootstrap.min.css?<?php echo date('d:m:y:h:i:s'); ?>">
<link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/animate-css/animate.min.css?<?php echo date('d:m:y:h:i:s'); ?>">
<link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/font-awesome/css/font-awesome.min.css?<?php echo date('d:m:y:h:i:s'); ?>">
<link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css?<?php echo date('d:m:y:h:i:s'); ?>">
<link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/chartist/css/chartist.min.css?<?php echo date('d:m:y:h:i:s'); ?>">
<link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/chartist-plugin-tooltip/chartist-plugin-tooltip.css?<?php echo date('d:m:y:h:i:s'); ?>">
<link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/sweetalert/sweetalert.css?<?php echo date('d:m:y:h:i:s'); ?>"/>
<link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css?<?php echo date('d:m:y:h:i:s'); ?>">
<link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/multi-select/css/multi-select.css?<?php echo date('d:m:y:h:i:s'); ?>">

<!-- MAIN CSS -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/main.css?<?php echo date('d:m:y:h:i:s'); ?>">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/color_skins.css?<?php echo date('d:m:y:h:i:s'); ?>">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/select2.min.css?<?php echo date('d:m:y:h:i:s'); ?>">
