<!doctype html>
<html lang="en">

<head>
    <title><?php echo $title; ?> | <?php echo get_siteconfig('website_name'); ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="description" content="">
    <meta name="author" content="">

    <?php $this->load->view('includes/header-styles.php'); ?>
</head>

<body class="theme-blue">
    <?php $this->load->view('includes/preloader.php'); ?>
    <!-- WRAPPER -->
    <div id="wrapper">
        <div class="vertical-align-wrap">
            <div class="vertical-align-middle auth-main">
                <div class="auth-box">
                    <div class="mobile-logo"><a href="#"><img src="<?php echo get_siteconfig('logo'); ?>" alt="Mplify"></a></div>
                    <div class="auth-left">
                        <!-- <div class="left-top">
                            <a href="#">
                                <img src="<?php echo base_url(); ?>assets/images/thumbnail.png" alt="Mplify">
                                <span>Mplify</span>
                            </a>
                        </div> -->
                        <div class="left-slider d-flex">
                            <div class="logo-sec">
                                <img src="<?php echo get_siteconfig('logo'); ?>" class="img-fluid logo" alt="">
                                <div class="coname"><?php echo get_siteconfig('website_name'); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="auth-right">
                        <!-- <div class="right-top">
                            <ul class="list-unstyled clearfix d-flex">
                                <li><a href="#"><i class="fa fa-home"></i></a></li>
                                <li><a href="javascript:void(0);">Help</a></li>
                                <li><a href="javascript:void(0);">Contact</a></li>
                            </ul>
                        </div> -->
                        <div class="card">
                            <div class="header">
                                <p class="lead">Log in</p>
                            </div>
                            <div class="body">
                                <?php echo form_open('auth', ['class' => "form-auth-small", 'id' => "basic-form"]); ?>
                                <?php if ($this->session->flashdata('last_page') != '') {
                                    $url = $this->session->flashdata('last_page');
                                } else {
                                    $url = base_url('dashboard');
                                } ?>
                                <input type="hidden" name="url" value="<?php echo $url; ?>">
                                <div class="form-group">
                                    <label for="signin-phone" class="control-label sr-only">E-Mail Id.</label>
                                    <input type="text" class="form-control <?php if (form_error('usr_email') != '') {
                                                                                echo "parsley-error";
                                                                            } ?>" id="signin-phone" name="usr_email" value="<?php echo set_value('usr_email'); ?>" placeholder="E-Mail Id." autofocus required>
                                    <?php if (form_error('usr_email') != '') { ?>
                                        <ul class="parsley-errors-list filled">
                                            <li class="parsley-required"><?php echo form_error('usr_email'); ?></li>
                                        </ul>
                                    <?php } ?>
                                </div>
                                <div class="form-group">
                                    <label for="signin-password" class="control-label sr-only">Password</label>
                                    <input type="password" class="form-control <?php if (form_error('password') != '') {
                                                                                    echo "parsley-error";
                                                                                } ?>" id="signin-password" name="password" value="" placeholder="Password" required>
                                    <?php if (form_error('password') != '') { ?>
                                        <ul class="parsley-errors-list filled">
                                            <li class="parsley-required"><?php echo form_error('password'); ?></li>
                                        </ul>
                                    <?php } ?>
                                </div>	
								<div class="multiselect_div">
									<label for="fin_year" class="control-label sr-only">Financial Year</label>
								
									<select id="fin_year" name="fin_year" class="multiselect multiselect-custom"  autofocus required>
										<?php 
										   list($fm,$fy)=explode("-",date("m-Y"));
											if($fm<=3){
												$fy=$fy-1;
											}else{
												$fy=$fy;
											}	
											for($i=2015;$i<=$fy;$i++) {
												$formated_fin_year = $i."-".($i+1); 
												?>
												<option value="<?php echo $i;?>" <?php if($i==$fy) echo "selected";?>/><?php echo $formated_fin_year ;?>
												
												<?php
												}
												?>
									</select>
								</div>
                                <div class="form-group">
                                    <label for="signin-logtype" class="control-label sr-only">User Type</label>
										<div class="multiselect_div">
											<?php
												
											?>
											<select id="logtype" name="logtype" class="multiselect multiselect-custom">
												<option value="0" selected="" disabled="" >User Type</option>
											<?php
												if ($results){
													foreach($results as $key => $row){
											?>	
												<option value="<?php echo $row->id ?>"><?php echo $row->group_name?></option>
											<?php
											}
												}
											?>
											</select>												
										</div>
                                </div>
								
                                <!-- <div class="form-group clearfix">
                                        <label class="fancy-checkbox element-left">
                                            <input type="checkbox">
                                            <span>Remember me</span>
                                        </label>								
                                    </div> -->
                                <!-- <button type="submit" name="loginbtn" class="btn btn-primary btn-lg btn-block">LOGIN</button> -->
                                <input type="submit" name="loginbtn" class="btn btn-primary btn-lg btn-block" value="LOGIN">
                                <div class="bottom">
                                    <!-- <span class="helper-text m-b-10"><i class="fa fa-lock"></i> <a href="<?php echo base_url('forgot-password'); ?>">Forgot password?</a></span> -->
                                    <span class="helper-text m-b-10"><i class="fa fa-lock"></i> <a href="#">Forgot password?</a></span>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END WRAPPER -->
    <?php $this->load->view('includes/footer-scripts.php'); ?>
<script src="<?php echo base_url();?>assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js?<?php echo date('d:m:y:h:i:s'); ?>"></script>
    <script>
        $(function() {
            $('#basic-form').parsley();
        });
		
		$('.datepicker').datepicker({format: 'dd-mm-yyyy'});
		
		$(document).ready(function () {
            $('.multiselect').multiselect({
                enableFiltering: true,
                enableCaseInsensitiveFiltering: true,
                maxHeight: 200
            });
			
		
		
        });

    </script>
</body>

</html>