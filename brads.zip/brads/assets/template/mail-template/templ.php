<?php
//if (!defined('BASEPATH')) exit('No direct script access allowed');
//echo doctype('html5')."\n";
?>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Welcome Email</title>
</head>

<body>
    <table width="650" border="0" align="center" cellspacing="0" cellpadding="0" style="border:14px solid #ededed; width:650px; margin:20px auto;">
        <tr>
            <td>
                <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
                    <tr style="border:0px;background-color:#ededed;">
                        <td valign="top" style="padding:15px;">
                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td width="63%" align="left" valign="top"><img src="{{image}}" alt=""></td>
                                    <td width="37%" align="right" valign=" middle"></td>
                                </tr>
                            </table>

                        </td>
                    </tr>
                </table>
                <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
                    <tr>
                        <td align="left" valign="top" style="padding:20px; font-family:Arial, Helvetica, sans-serif; font-size:14px; line-height:24px; color:#191b1f; text-align:left;">
                            <h3>Dear {{fname}},</h3>
                            <!--<p>Lorem Ipsum is simply dummy text of the printing and typesetting .</p>-->

                            <table width="100%" border="0" cellspacing="0" cellpadding="0" style="padding:12px; background-color:#ededed; font-size:15px;">
                                <tr>
                                    <td>
                                        {{message}}
                                    </td>
                                </tr>
                            </table>
                        
                        </td>
                    </tr>
                </table>
                <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" style="border:1px solid #d7d7d7; background:#ededed; padding:15px;">
                    <tr>
                        <td align="left" valign="middle" style="font-size:12px; font-family:Arial, Helvetica, sans-serif;  color:#333333; text-align: center;"> Copyright &copy; <?php echo date("Y"); ?> Kanteen India All Rights Reserved.</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>

</html>