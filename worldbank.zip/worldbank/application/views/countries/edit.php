<!doctype html>
<html lang="en">

<head>
    <title><?php echo $title; ?> | <?php /*echo get_siteconfig('website_name');*/ ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <?php $this->load->view('includes/header-styles.php'); ?>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/bootstrap-datepicker/css/bootstrap-datepicker3.min.css?<?php echo date('d:m:y:h:i:s'); ?>">
</head>

<body class="theme-blue">
    <?php $this->load->view('includes/preloader.php'); ?>
    <div id="wrapper">
        <?php $this->load->view('includes/header-menu.php'); ?>
        <?php $this->load->view('includes/sidebar-menu.php'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><?php echo $title; ?></h2>
                        </div>
                        <div class="col-lg-7 col-md-4 col-sm-12 text-right">
                            <ul class="breadcrumb justify-content-end">
                                <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item active"><?php echo $title; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="header">
                                <h2><?php echo $title; ?></h2>
                            </div>
                            <div class="body">
                                <?php
                                    $action_url = isset($results->id) ? "/".$results->id : '';
                                    $action_url = site_url($trigger.'edit').$action_url;
                                ?>
                                <?php echo form_open_multipart($action_url, ['class' => "form-auth-small", 'id' => "basic-form"]); ?>
                                <input type="hidden" value="<?php echo isset($results->id) ? $results->id : '' ;?>" name="id"/>
                                <div class="row clearfix">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label for="income_level" class="control-label">Income Level<span style="color:#f00;">*</span></label></label>
                                            <div class="multiselect_div">
                                            <input type="text" id="income_level" class="form-control <?php if (form_error('income_level') != '') { echo "parsley-error"; } ?>" name="income_level" placeholder="Income Level" value="<?php echo isset($results->income_level) ? $results->income_level : '' ;?>" >
                                            </div>
                                        </div>
                                    </div>  
									<div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label for="latitude" class="control-label">Latitude<span style="color:#f00;">*</span></label></label>
                                            <input type="text" id="latitude" class="form-control <?php if (form_error('latitude') != '') { echo "parsley-error"; } ?>" name="latitude" placeholder="Latitude" value="<?php echo isset($results->latitude) ? $results->latitude : '' ;?>" >
                                            <?php if (form_error('latitude') != '') { ?>
                                                <ul class="parsley-errors-list filled">
                                                    <li class="parsley-required"><?php echo form_error('latitude'); ?></li>
                                                </ul>
                                            <?php } ?>
                                        </div>
                                    </div> 
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label for="longitude" class="control-label">Longitude<span style="color:#f00;">*</span></label></label>
                                            <input type="text" id="longitude" class="form-control <?php if (form_error('longitude') != '') { echo "parsley-error"; } ?>" name="longitude" placeholder="Longitude" value="<?php echo isset($results->longitude) ? $results->longitude : '' ;?>" >
                                            <?php if (form_error('longitude') != '') { ?>
                                                <ul class="parsley-errors-list filled">
                                                    <li class="parsley-required"><?php echo form_error('longitude'); ?></li>
                                                </ul>
                                            <?php } ?>
                                        </div>
                                    </div> 
									<div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label for="capital_city" class="control-label">Capital City<span style="color:#f00;">*</span></label></label>
                                            <input type="text" id="capital_city" class="form-control <?php if (form_error('capital_city') != '') { echo "parsley-error"; } ?>" name="capital_city" placeholder="Capital City" value="<?php echo isset($results->capital_city) ? $results->capital_city : '' ;?>" >
                                            <?php if (form_error('capital_city') != '') { ?>
                                                <ul class="parsley-errors-list filled">
                                                    <li class="parsley-required"><?php echo form_error('capital_city'); ?></li>
                                                </ul>
                                            <?php } ?>
                                        </div>
                                    </div> 

                                    <div class="col-lg-12 col-md-6 col-sm-12">
                                        <div class="float-right">
                                            <input type="submit" name="submit-btn" class="btn btn-primary" value="<?php echo "Update"; ?>">
                                            <a href="<?php echo base_url($trigger); ?>" class="btn btn-danger">Cancel</a>
                                        </div>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $this->load->view('includes/footer-scripts.php'); ?>
    <script src="<?php echo base_url();?>assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js?<?php echo date('d:m:y:h:i:s'); ?>"></script>
    <?php if($option_mode == 'view'){ ?> 
        <script>
        $(document).ready(function () {
            $('#basic-form *').attr('disabled', 'disabled');
        });
        </script>
    <?php } ?>
   
   <script>
        $(document).ready(function () {
            $('#country_name').multiselect({
                enableFiltering: true,
                enableCaseInsensitiveFiltering: true,
                maxHeight: 200
            });
        });
    </script>					
	
</body>

</html>