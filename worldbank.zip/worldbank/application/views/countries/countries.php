<!doctype html>
<html lang="en"> 

<head>
    <title><?php echo $title; ?> | <?php /*echo get_siteconfig('website_name');*/ ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <?php $this->load->view('includes/header-styles.php'); ?>
    <?php $this->load->view('includes/datatables-styles.php'); ?>
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/toastr/toastr.min.css">
</head>

<body class="theme-blue">
    <?php $this->load->view('includes/preloader.php'); ?>
    <div id="wrapper">
        <?php $this->load->view('includes/header-menu.php'); ?>
        <?php $this->load->view('includes/sidebar-menu.php'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><?php echo $title; ?></h2>
                        </div>
                        <div class="col-lg-7 col-md-4 col-sm-12 text-right">
                            <ul class="breadcrumb justify-content-end">
                                <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i
                                            class="icon-home"></i></a></li>
                                <li class="breadcrumb-item active"><?php echo $title; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <?php if( get_user_rgt($this->session->userdata('user_group'), 'countries', 'add') ) { ?>
                                <a href="<?php echo base_url($trigger.'edit');?>" class="btn btn-primary m-b-15 float-right"><i class="icon wb-plus" aria-hidden="true"></i> Add <?php echo $title; ?></a>
                                <?php } ?>

                                <div class="table-responsive">
                                    <table
                                        class="table table-bordered table-striped table-hover dataTable js-exportable">
                                        <thead>
                                            <tr>
                                                <th>
                                                    <label class="fancy-checkbox">
                                                        <input class="select-all" type="checkbox" name="checkbox">
                                                        <span></span>
                                                    </label>
                                                </th>
                                                <th>Iso2 Code</th>
                                                <th>Country Name</th>
                                                <th>Region</th>
                                                <th>Income Level</th>
                                                <th>Capital City</th>
                                                <th>Latitude</th>
                                                <th>Longitude</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($results){ ?>
                                            <?php foreach ($results as $key => $row) { ?>
                                            <tr>
                                                <td style="width: 50px;">
                                                    <label class="fancy-checkbox">
                                                        <input class="checkbox-tick" type="checkbox" name="selected-row" value="<?php echo $row->id; ?>">
                                                        <span></span>
                                                    </label>
                                                </td>
                                                <td><?php echo $row->Iso2_code;?></td>
                                                <td><?php echo $row->name;?></td>
                                                <td><?php echo $row->region;?></td>
                                                <td><?php echo $row->income_level;?></td>
                                                <td><?php echo $row->capital_city;?></td>
                                                <td><?php echo $row->latitude;?></td>
                                                <td><?php echo $row->longitude;?></td>
                                                <td>
                                                    <a href="<?php echo base_url($trigger.'edit/'.$row->id); ?>" class="btn btn-sm btn-icon btn-pure btn-default on-default m-r-5 button-edit" data-toggle="tooltip" data-original-title="Edit" onClick="confirm('Are you want to edit this row?');"><i class="icon-pencil" aria-hidden="true"></i></a>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                            <?php }else{?>
                                                <tr>
                                                    <td style="width: 50px;"></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>
                                                    <label class="fancy-checkbox">
                                                        <input class="select-all" type="checkbox" name="checkbox">
                                                        <span></span>
                                                    </label>
                                                </th>
                                                <th>Iso2 Code</th>
                                                <th>Country Name</th>
                                                <th>Region</th>
                                                <th>Income Level</th>
                                                <th>Capital City</th>
                                                <th>Latitude</th>
                                                <th>Longitude</th>
                                                <th>Actions</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $this->load->view('includes/footer-scripts.php'); ?>
    <?php $this->load->view('includes/datatables-scripts.php'); ?>
    <script>


    </script>
    <script src="<?php echo base_url(); ?>assets/vendor/toastr/toastr.js"></script>
    <?php if($this->session->flashdata('insertion_success_msg')){ ?>
        <script>
            $(function () {
                toastr.remove();
                toastr['success']('Country added Successfully.', '', {
                    timeOut: 3000,
                    closeButton: true,
                    positionClass: 'toast-top-right'
                });
            });
        </script>
    <?php } ?>
    <?php if($this->session->flashdata('insertion_error_msg')){ ?>
        <script>
            $(function () {
                toastr.remove();
                toastr['error']('Country not added. Please Try again later.', '', {
                    timeOut: 3000,
                    closeButton: true,
                    positionClass: 'toast-top-right'
                });
            });
        </script>
    <?php } ?>
    <?php if($this->session->flashdata('update_success_msg')){ ?>
        <script>
            $(function () {
                toastr.remove();
                toastr['success']('Country updated Successfully.', '', {
                    timeOut: 3000,
                    closeButton: true,
                    positionClass: 'toast-top-right'
                });
            });
        </script>
    <?php } ?>
    <?php if($this->session->flashdata('update_failure_msg')){ ?>
        <script>
            $(function () {
                toastr.remove();
                toastr['error']('Country not updated. Please Try again later.', '', {
                    timeOut: 3000,
                    closeButton: true,
                    positionClass: 'toast-top-right'
                });
            });
        </script>
    <?php } ?>
    <?php if($this->session->flashdata('countries_status_success')){ ?>
        <script>
            $(function () {
                toastr.remove();
                toastr['success']('Country status updated successfully.', '', {
                    timeOut: 3000,
                    closeButton: true,
                    positionClass: 'toast-top-right'
                });
            });
        </script>
    <?php } ?>
    <?php if($this->session->flashdata('countries_status_error')){ ?>
        <script>
            $(function () {
                toastr.remove();
                toastr['error']('Country status not updated. Please Try again later.', '', {
                    timeOut: 3000,
                    closeButton: true,
                    positionClass: 'toast-top-right'
                });
            });
        </script>
    <?php } ?>
    <?php if($this->session->flashdata('countries_delete_success')){ ?>
        <script>
            $(function () {
                toastr.remove();
                toastr['success']('Country deleted successfully.', '', {
                    timeOut: 3000,
                    closeButton: true,
                    positionClass: 'toast-top-right'
                });
            });
        </script>
    <?php } ?>
    <?php if($this->session->flashdata('Countries_delete_error')){ ?>
        <script>
            $(function () {
                toastr.remove();
                toastr['error']('Country is not deleted succesfully. Please try again.', '', {
                    timeOut: 3000,
                    closeButton: true,
                    positionClass: 'toast-top-right'
                });
            });
        </script>
    <?php } ?>
</body>

</html>