<div id="leftsidebar" class="sidebar">
    <div class="sidebar-scroll">
        <nav id="leftsidebar-nav" class="sidebar-nav">
            <ul id="main-menu" class="metismenu">
                <li class="heading">Main</li>
                <li class="<?php if($this->uri->segment(1) == 'Dataload'){ echo "active";}?>"><a href="<?php echo base_url('/Dataload'); ?>"><i class="icon-user"></i><span>Data Load from API</span></a></li>

				<li class="<?php if($this->uri->segment(1) == 'Countries'){ echo "active";}?>"><a href="<?php echo base_url('/Countries'); ?>"><i class="icon-user"></i><span>Country</span></a></li>
            </ul>
        </nav>
    </div>
    
</div>