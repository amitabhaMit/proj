<nav class="navbar navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-brand">
        </div>
        <div class="navbar-right">
            <ul class="list-unstyled clearfix mb-0">
                <li>
                    <div class="navbar-btn btn-toggle-show">
                        <button type="button" class="btn-toggle-offcanvas"><i class="lnr lnr-menu fa fa-bars"></i></button>
                    </div>                        
                    <a href="javascript:void(0);" class="btn-toggle-fullwidth btn-toggle-hide"><i class="fa fa-bars"></i></a>
                </li>
                <li>
                </li>
                <li>

                </li>
            </ul>
        </div>
    </div>
</nav>