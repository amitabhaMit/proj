<!-- Javascript -->
<script src="<?php echo base_url();?>assets/bundles/libscripts.bundle.js"></script>    
<script src="<?php echo base_url();?>assets/bundles/vendorscripts.bundle.js"></script>

<script src="<?php echo base_url();?>assets/bundles/chartist.bundle.js"></script>
<script src="<?php echo base_url();?>assets/bundles/knob.bundle.js"></script> <!-- Jquery Knob-->
<script src="<?php echo base_url();?>assets/bundles/flotscripts.bundle.js"></script> <!-- flot charts Plugin Js --> 
<script src="<?php echo base_url();?>assets/vendor/flot-charts/jquery.flot.selection.js"></script>
<script src="<?php echo base_url();?>assets/vendor/multi-select/js/jquery.multi-select.js"></script> <!-- Multi Select Plugin Js -->
<script src="<?php echo base_url();?>assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
<script src="<?php echo base_url();?>assets/vendor/parsleyjs/js/parsley.min.js"></script>
<script src="<?php echo base_url();?>assets/bundles/mainscripts.bundle.js"></script>
<script src="<?php echo base_url();?>assets/js/index.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.maskedinput.min.js"></script>
<script src="<?php echo base_url();?>assets/js/select2.min.js"></script>
<script src="<?php echo base_url();?>assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script>
    $(function() {
        // initialize after multiselect
        $('#basic-form').parsley();
		
    });
	
</script>
<script type="text/javascript">
//prevent submission of forms when pressing Enter key in a text input
	$(document).on('keypress', ':input:not(text,date):not([type=submit])', function (e) {
		if (e.which == 13) e.preventDefault();
	});
			
			
	$(function() {
	$('input[type="file"]').change(function(e){
	var fileName = e.target.files[0].name;
	$(this).next('label').text(fileName);
});
	});
</script>

