<!-- DATATABLES JS -->
<script src="<?php echo base_url();?>assets/bundles/datatablescripts.bundle.js?<?php echo date('d:m:y:h:i:s'); ?>"></script>
<script src="<?php echo base_url();?>assets/vendor/jquery-datatable/buttons/dataTables.buttons.min.js?<?php echo date('d:m:y:h:i:s'); ?>"></script>
<script src="<?php echo base_url();?>assets/vendor/jquery-datatable/buttons/buttons.bootstrap4.min.js?<?php echo date('d:m:y:h:i:s'); ?>"></script>
<script src="<?php echo base_url();?>assets/vendor/jquery-datatable/buttons/buttons.colVis.min.js?<?php echo date('d:m:y:h:i:s'); ?>"></script>
<script src="<?php echo base_url();?>assets/vendor/jquery-datatable/buttons/buttons.html5.min.js?<?php echo date('d:m:y:h:i:s'); ?>"></script>
<script src="<?php echo base_url();?>assets/vendor/jquery-datatable/buttons/buttons.print.min.js?<?php echo date('d:m:y:h:i:s'); ?>"></script>
<!-- <script src="<?php echo base_url();?>assets/vendor/jquery-datatable/buttons/pdfmake.min.js?<?php echo date('d:m:y:h:i:s'); ?>"></script> -->

<script src="<?php echo base_url();?>assets/bundles/morrisscripts.bundle.js?<?php echo date('d:m:y:h:i:s'); ?>"></script>
<script src="<?php echo base_url();?>assets/js/pages/tables/jquery-datatable.js?<?php echo date('d:m:y:h:i:s'); ?>"></script>