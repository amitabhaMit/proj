<!-- DATATABLES CSS -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css?<?php echo date('d:m:y:h:i:s'); ?>">
<link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/jquery-datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css?<?php echo date('d:m:y:h:i:s'); ?>">
<link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/jquery-datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css?<?php echo date('d:m:y:h:i:s'); ?>">

<style>
    td.details-control {
        background: url('<?php echo base_url(); ?>assets/images/details_open.png') no-repeat center center;
        cursor: pointer;
    }
    tr.shown td.details-control {
        background: url('<?php echo base_url(); ?>assets/images/details_close.png') no-repeat center center;
    }
</style>
