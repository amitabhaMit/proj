<?php

defined('BASEPATH') or exit('No direct script access allowed');
/**
 * Common Model Class
 *
 * @package		DTech System 
 * @subpackage	Common Database Operations
 * @category	Common Database Operations
 * @author		DTech System Developer Group
 *
 * https://github.com/temori1919/common_models/blob/master/Crud_model.php
 * https://github.com/AH72KING/CommonModel/blob/master/Common_model.php
 * https://snipplr.com/view/92890/commonly-used-db-functions-for-codeigniter/
 */
class Commonmodel extends CI_Model
{

    /**
     * 
     * Insert record into table
     * 
     * @param string $tablename
     * @param array $data [insertdata array(column_name => value)]
     * @return int/bool	Last inserted id on success, FALSE on failure
     */
    public function data_insert($tablename, $data)
    {
        if ($this->db->insert($tablename, $data)) {
            if($this->db->insert_id()){
				return $this->db->insert_id();
			}elseif($this->db->affected_rows()){
				return $this->db->affected_rows();
			}
		}else {
            return false;
        }
    }
	
    /*public function data_insert_tran($tablename, $data)
    {
        if ($this->db->insert($tablename, $data)) {
			return $this->db->affected_rows();			
        } else {
            return false;
        }
    }*/
	
    // --------------------------------------------------------------------

    /**
     * 
     * Update specified record
     * 
     * @param  string $tablename [table name]
     * @param  array  $data   [updatedata array(column_name => value)]
     * @param  array  $target [where clause array(column_name => value)]
     * @return bool	TRUE on success, FALSE on failure
     */
    public function data_update($tablename, $data, $target)
    {
        $this->db->set($data);
        $this->db->where($target);
        return $this->db->update($tablename);
    }
    // --------------------------------------------------------------------

    /**
     * 
     * Update status
     * 
     * @param  string $tablename [table name]
     * @param  string $key [column_name]
     * @return bool	TRUE on success, FALSE on failure
     */
    /*function change_status($tablename, $key, $id, $target)
	{
		return $target->query("UPDATE 
							`".$tablename."` 
						SET `is_active` = (1-`is_active`)
						WHERE 
							`".$key."` = '".$id."'");
    }*/
    function change_status($tablename, $key, $id)
	{
		return $this->db->query("UPDATE 
							".$tablename."
						SET `is_active` = (1-`is_active`)
						WHERE 
							`".$key."` = '".$id."'");
    }
    // --------------------------------------------------------------------

    /**
     * 
     * Update status bulk
     * 
     * @param  string $tablename [table name]
     * @param  string $key [column_name]
     * @return bool	TRUE on success, FALSE on failure
     */
    function change_status_bulk($table_name, $status, $key, $id)
	{
		return  $this->db->query("UPDATE 
							".$table_name." 
						SET 
							`is_active` = ".$status."
						WHERE 
							`".$key."` = '".$id."'");
    }
    // --------------------------------------------------------------------

    /**
     * 
     * Delete specified record
     * 
     * @param  string $tablename [table name]
     * @param  array $target    [where clause array(column_name => value)]
     */
    public function data_delete($tablename, $target)
    {
        $this->db->where($target);
        return $this->db->delete($tablename);
    }
    // --------------------------------------------------------------------

    /**
     * 
     * Select Data from table
     * 
     * @param string $tablename
     * @param string/array $where
     * @param string/array $groupby
     * @param string $orderby
     * @param string $direction
     * @return int/bool	result array on success, FALSE on failure
     */
    public function data_select($tablename, $isarray = false, $where = false, $orderby = false, $direction = "ASC", $groupby = false)
    {
        if ($where) {
            if (is_array($where)) {
                foreach ($where as $key => $val) {
                    $this->db->where($key, $val);
                }
            } else {
                $this->db->where($where);
            }
        }

        if ($orderby) {
            $this->db->order_by($orderby, $direction);
        }

        if ($groupby) {
            if (is_array($groupby)) {
                foreach ($groupby as $key => $val) {
                    $this->db->group_by($val);
                }
            } else {
                $this->db->group_by($groupby);
            }
        }

        $result = $this->db->get($tablename);

        if ($result->num_rows() > 0) {
            if ($isarray) {
                return $result->result_array();
            } else {
                return $result->result();
            }
        } else {
            return false;
        }
    }
    // --------------------------------------------------------------------

    /**
     * 
     * Select Data from table
     * 
     * @param string $tablename
     * @param string/array $where
     * @param string/array $groupby
     * @param string $orderby
     * @param string $direction
     * @return int/bool	result array on success, FALSE on failure
     */
    public function data_select_record($tablename, $where = false)
    {
        if ($where) {
            if (is_array($where)) {
                foreach ($where as $key => $val) {
                    $this->db->where($key, $val);
                }
            } else {
                $this->db->where($where);
            }
        }

        $result = $this->db->get($tablename);

        if ($result->num_rows() > 0) {
            return $result->row();
        } else {
            return false;
        }
    }
    // --------------------------------------------------------------------
    
    /**
     * 
     * Count Data from table
     * 
     * @param string $tablename
     * @param string/array $where
     * @param string/array $groupby
     * @param string $orderby
     * @param string $direction
     * @return int	result array on success
     */
    public function data_count_record($tablename, $where = false)
    {
        if ($where) {
            if (is_array($where)) {
                foreach ($where as $key => $val) {
                    $this->db->where($key, $val);
                }
            } else {
                $this->db->where($where);
            }
        }

        $result = $this->db->get($tablename);

        return $result->num_rows();
    }
    // --------------------------------------------------------------------

    /**
     * 
     * Select Data from table for Dropdown
     * 
     * @param string $tablename Table Name
     * @param string $id Option Id
     * @param string $name Option Name(Display in Dropdown)
     * @param string/array $where (Conditions)
     * @param string $orderby
     * @return string A dropdow option list
     */
    public function data_get_select_option_where_clause($tablename, $id, $name, $selected = false, $where = false, $orderby = false)
    {
        if ($where) {
            if (is_array($where)) {
                foreach ($where as $key => $val) {
                    $this->db->where($key, $val);
                }
            } else {
                $this->db->where($where);
            }
        }

        if ($orderby) {
            $this->db->order_by($orderby, "ASC");
        }
        
		$query = $this->db->get($tablename);
        $select = '';
        if ($query->num_rows() > 0) {
            foreach ($query->result_array() as $row) {
                $selected_option = '';
                if ($selected && $selected == $row[$id]) {
                    $selected_option = 'selected="selected"';
                }
				if ($name) {
					if (is_array($name)) {
						$output = "";
						foreach ($name as $key => $val) {
							$output.= trim(strtoupper($row[$val]))." ";							
						}
						$select .= '<option value="' . $row[$id] . '" ' . $selected_option . '>' . $output . '</option>';
					} else {
						$select .= '<option value="' . $row[$id] . '" ' . $selected_option . '>' . trim(strtoupper($row[$name])). '</option>';							
					}
				}
			}				
        }
        return $select;
    }
    // --------------------------------------------------------------------

    /**
     * 
     * Get the Last Id of a paritcular column.  
     * 
     * @param string $tablename Table Name
     * @param string $fieldname Name of the Field.
     * @return int the id
     */
    public function data_get_last_id($tablename = '', $fieldname)
    {
        $this->db->select_max($fieldname);
        $this->db->from($tablename);
        $results = $this->db->get()->row();
        if ($results->$fieldname == '') {
            $last_id = 0;
        } else {
            $last_id = $results->$fieldname;
        }
        return $last_id;
    }
    // --------------------------------------------------------------------

    /**
     * 
     * Get the site options.  
     * 
     * @param string $key Option
     * @return string the value of the site config
     */
    function data_get_siteconfig($key)
    {
        $this->db->where('_key', $key);
        $setting = $this->db->get('config');
        if ($setting->num_rows() > 0) {
            $config = $setting->row();
            $value  = $config->value;
        } else {
            $value = '';
        }
        return $value;
    }
    // --------------------------------------------------------------------
    /**
     * 
     * Select Data from table
     * 
     * @param string $tablename
     * @param string/array $where
     * @param string/array $groupby
     * @param string $orderby
     * @param string $direction
     * @return int/bool	result array on success, FALSE on failure
     */
    public function data_select_join($table, $join_conds, $join_type = false, $select, $isarray = false, $where = false, $like = false, $or_like = false, $orderby = false, $direction = "ASC", $groupby = false)
    {
        if ($table != false)
                $this->db->from($table);
		
		if ($join_conds) {
            if (is_array($join_conds)) {
                foreach ($join_conds as $key => $val) {
					if ($join_type) {
						$this->db->join($key, $val, $join_type);
					} else {
						$this->db->join($key, $val);
					}
                }
            } /*else {
               $this->db->join($join_conds, $table1.'vendor_name'=join_conds.'v_id');
            }*/
        }		
		
        if ($where) {
            if (is_array($where)) {
                foreach ($where as $key => $val) {
                    $this->db->where($key, $val);
                }
            } else {
                $this->db->where($where);
            }
        }
		
        if ($like) {
            if (is_array($like)) {
                foreach ($like as $key => $val) {
                    $this->db->like($key, $val);
                }
            } else {
                $this->db->like($like);
            }
        }
		
        if ($or_like) {
            if (is_array($or_like)) {
                foreach ($or_like as $key => $val) {
                    $this->db->or_like($key, $val);
                }
            } else {
                $this->db->like($like);
            }
        }
		
		

        if ($orderby) {
            $this->db->order_by($orderby, $direction);
        }

        if ($groupby) {
            if (is_array($groupby)) {
                foreach ($groupby as $key => $val) {
                    $this->db->group_by($val);
                }
            } else {
                $this->db->group_by($groupby);
            }
        }
		
		if ($select) {
                $this->db->select($select);
        }

		
        $result = $this->db->get();
        if ($result->num_rows() > 0) {
            if ($isarray) {
                return $result->result_array();
            } else {
				return $result->result();
            }
        } else {
            return false;
        }
    }
    // --------------------------------------------------------------------
    /**
     * 
     * Count Data from table
     * 
     * @param string $tablename
     * @param string/array $where
     * @param string/array $groupby
     * @param string $orderby
     * @param string $direction
     * @return int	result array on success
     */
    public function data_select_agreegate_function($tablename, $fieldname, $function, $where = false)
    {
        /*if ($sum) {
            $this->db->select_sum($sum);			
        }*/

		if ($function == 'sum'){
			$this->db->select_sum($fieldname);
		}else if ($function == 'max'){
			$this->db->select_max($fieldname);			
		}
		
		
        /*if ($fieldname) {
            if (is_array($fieldname)) {
                foreach ($where as $key => $val) {
					if $key = 'sum'{
						$this->db->select_sum($fieldname);
					}else if $key = 'max'{
						$this->db->select_max($fieldname);			
					}
				}
            } else {
                $this->db->where($where);
            }
        }*/
		
		
        if ($where) {
            if (is_array($where)) {
                foreach ($where as $key => $val) {
                    $this->db->where($key, $val);
                }
            } else {
                $this->db->where($where);
            }
        }

        $result = $this->db->get($tablename);
		
        if ($result->num_rows() > 0) {
            return $result->row();
        } else {
            return false;
        }
    }
    // --------------------------------------------------------------------
	
	
}
                        
/* End of file Commonmodel.php */
