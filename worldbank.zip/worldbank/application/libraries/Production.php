<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
                        
class Production
{
    public function __construct()
    {
        $this->CI = get_instance();                       
    }
                        
}
                                                
/* End of file Production.php */
    
                        