<?php 
        
defined('BASEPATH') OR exit('No direct script access allowed');
        
class Dataload extends MY_Controller {

    protected $title    = 'Data Load from API';
	protected $trigger  = 'Dataload/';
    protected $trigger1 = 'Countries/';

	protected $table = 'countries';
        
    public function __construct()
	{
		parent::__construct();
		//is_logged_in();
    }
    
    public function index()
    {
        $data = array();
		$data['title'] 	    = $this->title;
		$data['trigger']    = $this->trigger;
        $data['table']	    = $this->table;
        
        
        $this->load->view('dataload/edit', $data);
    }

    public function edit($id = false)
    {

        $data = array();
		$data['title'] 		= $this->title;
		$data['trigger']	= $this->trigger;
        $data['table']	    = $this->table;
                
        if($this->input->post('submit-btn')){

            $error_msg = '';
            $headers = array(
                'Accept: application/json',
                'Content-Type: application/json'
              );
        
            $url = "https://api.worldbank.org/v2/country?format=json";
            //echo $url;// die();

            $ch = curl_init();
            //curl_setopt($ch, CURLOPT_POST,true);
            //curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Length: ' . strlen($fields)));
            //curl_setopt($ch, CURLOPT_POSTFIELDS,$data_json);
            curl_setopt($ch, CURLOPT_URL,$url);
            //curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);				
            //curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
          
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_FAILONERROR, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            //curl_setopt($ch, CURLOPT_POSTFIELDS, $query);
            //curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_NTLM);
            $result = curl_exec($ch);
          
            if (curl_errno($ch)) {
              $error_msg = curl_error($ch);
            }
            curl_close($ch);

            if (isset($error_msg)) {
              echo $error_msg;  
            }

            $final_res=json_decode($result, true);
            // echo "<pre>";
            // print_r($final_res);
            // echo "</pre>";
            //$final_res=$final_res[0]['PostOffice'];
            foreach($final_res as $key => $row_final_res){

                if ($key > 0){
                    foreach($final_res[$key] as $key1 => $row_final_res1){
                        // echo ($row_final_res1['iso2Code']. '; \n');
                        // echo ($row_final_res1['region']['value']. '; \n');

                        $data_array = array(
                            'Iso2_code'         => $row_final_res1['iso2Code'],
                            'name'              => $row_final_res1['name'],
                            'region'            => $row_final_res1['region']['value'],
                            'income_level'      => $row_final_res1['incomeLevel']['value'],
                            'capital_city'      => $row_final_res1['capitalCity'],
                            'latitude'          => $row_final_res1['latitude'],
                            'longitude'         => $row_final_res1['longitude']
                        );
                        $id = $this->common_model->data_insert($data['table'], $data_array);
                        if ($id) {
                            $this->session->set_flashdata('insertion_success_msg', 'Created successfully !!');
                        } else {
                            $this->session->set_flashdata('insertion_error_msg', 'Error while creating !!');
                        }
                         
                    }
                }
                
            }
  

            redirect($this->trigger1);


        }

    }

    

    


}
        
    /* End of file  Users.php */
        
                            