<?php 
        
defined('BASEPATH') OR exit('No direct script access allowed');
        
class Countries extends MY_Controller {

    protected $title = 'Country';
	protected $trigger = 'Countries/';
	protected $table = 'countries';
        
    public function __construct()
	{
		parent::__construct();
		//is_logged_in();
    }
    
    public function index()
    {
        $data = array();
		$data['title'] 	    = $this->title;
		$data['trigger']    = $this->trigger;
        $data['table']	    = $this->table;
        
        $data['results'] = $this->common_model->data_select($data['table'], false, false, 'name');
        
        $this->load->view('countries/countries', $data);
    }

    public function edit($id = false)
    {

        $data = array();
		$data['title'] 		= $this->title;
		$data['trigger']	= $this->trigger;
        $data['table']	    = $this->table;
                
        if($this->input->post('submit-btn')){

            $id = $this->input->post('id');
            
            #Setting the Rules
            $this->form_validation->set_rules('income_level', 'Income Level', 'trim|required');
            $this->form_validation->set_rules('latitude', 'Latitude', 'trim|required');
            $this->form_validation->set_rules('longitude', 'Longitude', 'trim|required');
            $this->form_validation->set_rules('capital_city', 'Capital City', 'trim|required');

            $this->form_validation->set_error_delimiters('<div style="color:red">', '</div>');
            if ($this->form_validation->run()) {
                if($id){
                    $data_array = array(
                        'income_level'               => $this->input->post('income_level'),
                        'latitude'                   => $this->input->post('latitude'),
                        'longitude'                  => $this->input->post('longitude'),
                        'capital_city'               => ucwords($this->input->post('capital_city'))
                    );
					
                    $update = $this->common_model->data_update($data['table'], $data_array, ['id' => $id]);
                    if ($update) {
                        $this->session->set_flashdata('update_success_msg', 'Updated successfully !!');
                    } else {
                        $this->session->set_flashdata('update_failure_msg', 'Updated successfully !!');
                    }
					
                }else{
                    $data_array = array(
                        'name'              => ucwords($this->input->post('name')),
                        'modified_by'        => $this->session->email,
                        'created_at'         => date("Y-m-d H:i:s",time()),
                        'updated_at'         => date("Y-m-d H:i:s",time())
                    );
					
                    $id = $this->common_model->data_insert($data['table'], $data_array);
                    if ($id) {
                        $this->session->set_flashdata('insertion_success_msg', 'Created successfully !!');
                    } else {
                        $this->session->set_flashdata('insertion_error_msg', 'Error while creating !!');
                    }
					
                }
                redirect($this->trigger);
            }
        }

        $data['title'] 			= 	'Add Country';
		$data['option_mode']    =   'add';
		if($id)
		{
			$data['title'] 			= 	'Edit Country';
			$data['option_mode']    =   'edit';
			
			$data['results']		= 	$this->common_model->data_select_record($data['table'], ['id' => $id]);
		}		
		$this->load->view('countries/edit', $data);
    }

    

    


}
        
    /* End of file  Users.php */
        
                            