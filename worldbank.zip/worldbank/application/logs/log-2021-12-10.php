ERROR - 2021-12-10 18:21:15 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-12-10 18:21:15 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-12-10 18:21:20 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-12-10 18:21:20 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-12-10 18:21:20 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-12-10 18:21:26 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-12-10 18:21:27 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-12-10 19:07:11 --> 404 Page Not Found: Dataload/index
